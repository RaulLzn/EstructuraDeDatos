package raul.Model.util.Queue;

import raul.Model.util.collection.AbstractCollection;

public abstract class AbstractQueue<E> extends AbstractCollection<E> implements Queue<E>{

}
