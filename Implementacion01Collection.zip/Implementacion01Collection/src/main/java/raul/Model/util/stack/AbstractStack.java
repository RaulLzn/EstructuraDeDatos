package raul.Model.util.stack;

import raul.Model.util.collection.AbstractCollection;

public abstract class AbstractStack<E> extends AbstractCollection<E> implements Stack<E>{

}
