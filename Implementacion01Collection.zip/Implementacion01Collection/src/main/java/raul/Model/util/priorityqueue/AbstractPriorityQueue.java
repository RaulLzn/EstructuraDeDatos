package raul.Model.util.priorityqueue;


import raul.Model.util.collection.AbstractCollection;

public abstract class AbstractPriorityQueue<E> extends AbstractCollection<E> implements PriorityQueue<E>  {

}
