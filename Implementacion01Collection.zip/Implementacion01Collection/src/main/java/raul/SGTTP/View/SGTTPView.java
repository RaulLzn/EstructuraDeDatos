package raul.SGTTP.View;

public class SGTTPView {

    public void init(String title) {
        System.out.println("*******************************************");
        System.out.println("SGTTPView " + title + " *");
        System.out.println("*******************************************");
    }
}
