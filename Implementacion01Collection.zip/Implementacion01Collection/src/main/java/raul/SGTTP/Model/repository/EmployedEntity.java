package raul.SGTTP.Model.repository;

public class EmployedEntity {

    String id;
    String names;
    String lastNames;
    String phoneNumbers;

    public EmployedEntity(String id, String names, String lastNames, String phoneNumbers) {
        this.id = id;
        this.names = names;
        this.lastNames = lastNames;
        this.phoneNumbers = phoneNumbers;
    }

}
