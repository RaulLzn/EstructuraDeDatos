package raul.SGTTP.Model;

import raul.Model.linkedlist.singly.LinkedList;

public class SGTTPModel {

    LinkedList<String> list = new LinkedList<String>();

    private String title = "SGTTP MVC";

    public String getTitle() {
        return title;
    }

}
