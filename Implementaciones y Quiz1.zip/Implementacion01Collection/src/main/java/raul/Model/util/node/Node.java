package raul.Model.util.node;

public interface Node<E> {

    public void set (E element);

    public E get();

    public String toString();
}
